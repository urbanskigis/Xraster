import numpy as np
import pandas as pd
import xarray as xr

# --------------------------------------------------
# Input files
# --------------------------------------------------
nc_file = r"D:\XRAST\wersja5\MSHW\MS_object.nc"
cat_file = r"D:\XRAST\wersja5\MSHW\MHW_cat1_sum_5days_100km2.csv"
output_file = r"D:\XRAST\wersja5\MSHW\MS_objectFFF2.nc"

variable_name = "days5_100km2"

# --------------------------------------------------
# Read MHW IDs
# --------------------------------------------------
df = pd.read_csv(cat_file)

mhw_ids = df["id"].dropna().astype(np.uint16).values

# --------------------------------------------------
# Open NetCDF
# --------------------------------------------------
ds = xr.open_dataset(nc_file)

region = ds["region_ID"]

# --------------------------------------------------
# Create binary mask
# --------------------------------------------------
binary = np.isin(
    region.values,
    mhw_ids
).astype(np.uint8)

# --------------------------------------------------
# Create new variable
# --------------------------------------------------
ds[variable_name] = xr.DataArray(
    binary,
    dims=region.dims,
    coords=region.coords,
    attrs={
        "long_name": "MHW binary mask"
    }
)

# --------------------------------------------------
# Remove original region_ID
# --------------------------------------------------
ds = ds.drop_vars("region_ID")

# --------------------------------------------------
# Save
# --------------------------------------------------
ds.to_netcdf(output_file)

