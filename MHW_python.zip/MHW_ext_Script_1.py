import numpy as np
import pandas as pd
from datetime import timedelta

# --------------------------------------------------
# Input and OUTPUT files
# --------------------------------------------------

INPUT_FILE = "D:\XRAST\wersja5\MSHW\MHW_cat1_sum.csv" 
OUTPUT_FILE = "D:\XRAST\wersja5\MSHW\MHW_cat1_sum_5days_100km2B.csv"  # 1

# ==========================
# Parameters
# ==========================

YXkm2 = 24.15         # km2 per cell
AREAMIN = 100          # minimum area [km2]
DAYMAX = 5             # minimum number of days

# ==========================
# Read data
# ==========================
df = pd.read_csv(INPUT_FILE)

# Convert dates
df["date_start"] = pd.to_datetime(df["date_start"])
df["date_end"] = pd.to_datetime(df["date_end"])

# Calculate the number of days
df["days"] = (df["date_end"] - df["date_start"]).dt.days + 1

# Calculate the area
df["area_km2"] = df["max_number_of_cells"] * YXkm2

# Filtering
df_filtered = df[
    (df["area_km2"] >= AREAMIN) &
    (df["days"] >= DAYMAX)
]

# Save
df_filtered.to_csv(OUTPUT_FILE, index=False, date_format="%Y-%m-%d")

print(f"Saved {len(df_filtered)} records to file {OUTPUT_FILE}")